<?php

namespace App\Http\Livewire\McodeCommunication;

use App\Models\McodeCommunication;
use Livewire\Component;

class Create extends Component
{
    public McodeCommunication $mcodeCommunication;

    public function mount(McodeCommunication $mcodeCommunication)
    {
        $this->mcodeCommunication = $mcodeCommunication;
    }

    public function render()
    {
        return view('livewire.mcode-communication.create');
    }

    public function submit()
    {
        $this->validate();

        $this->mcodeCommunication->save();

        return redirect()->route('admin.mcode-communications.index');
    }

    protected function rules(): array
    {
        return [
            'mcodeCommunication.name' => [
                'string',
                'nullable',
            ],
            'mcodeCommunication.param' => [
                'string',
                'nullable',
            ],
            'mcodeCommunication.description' => [
                'string',
                'nullable',
            ],
        ];
    }
}
