<?php

namespace App\Http\Livewire\McodeFeature;

use App\Models\McodeCategory;
use App\Models\McodeCommunication;
use App\Models\McodeFeature;
use Livewire\Component;

class Edit extends Component
{
    public array $catagories = [];

    public array $listsForFields = [];

    public McodeFeature $mcodeFeature;

    public array $communication_modes = [];

    public function mount(McodeFeature $mcodeFeature)
    {
        $this->mcodeFeature        = $mcodeFeature;
        $this->catagories          = $this->mcodeFeature->catagories()->pluck('id')->toArray();
        $this->communication_modes = $this->mcodeFeature->communicationModes()->pluck('id')->toArray();
        $this->initListsForFields();
    }

    public function render()
    {
        return view('livewire.mcode-feature.edit');
    }

    public function submit()
    {
        $this->validate();

        $this->mcodeFeature->save();
        $this->mcodeFeature->catagories()->sync($this->catagories);
        $this->mcodeFeature->communicationModes()->sync($this->communication_modes);

        return redirect()->route('admin.mcode-features.index');
    }

    protected function rules(): array
    {
        return [
            'mcodeFeature.published' => [
                'boolean',
            ],
            'mcodeFeature.state' => [
                'string',
                'nullable',
            ],
            'mcodeFeature.name' => [
                'string',
                'nullable',
            ],
            'mcodeFeature.content_name' => [
                'string',
                'nullable',
            ],
            'mcodeFeature.description' => [
                'string',
                'nullable',
            ],
            'mcodeFeature.content_description' => [
                'string',
                'nullable',
            ],
            'catagories' => [
                'array',
            ],
            'catagories.*.id' => [
                'integer',
                'exists:mcode_categories,id',
            ],
            'communication_modes' => [
                'array',
            ],
            'communication_modes.*.id' => [
                'integer',
                'exists:mcode_communications,id',
            ],
            'mcodeFeature.template' => [
                'string',
                'nullable',
            ],
            'mcodeFeature.mcode' => [
                'string',
                'nullable',
            ],
            'mcodeFeature.source_string' => [
                'string',
                'nullable',
            ],
            'mcodeFeature.safe_source' => [
                'string',
                'nullable',
            ],
        ];
    }

    protected function initListsForFields(): void
    {
        $this->listsForFields['catagories']          = McodeCategory::pluck('name', 'id')->toArray();
        $this->listsForFields['communication_modes'] = McodeCommunication::pluck('name', 'id')->toArray();
    }
}
