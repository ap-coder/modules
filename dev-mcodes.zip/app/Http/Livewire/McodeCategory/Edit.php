<?php

namespace App\Http\Livewire\McodeCategory;

use App\Models\McodeCategory;
use Livewire\Component;

class Edit extends Component
{
    public McodeCategory $mcodeCategory;

    public function mount(McodeCategory $mcodeCategory)
    {
        $this->mcodeCategory = $mcodeCategory;
    }

    public function render()
    {
        return view('livewire.mcode-category.edit');
    }

    public function submit()
    {
        $this->validate();

        $this->mcodeCategory->save();

        return redirect()->route('admin.mcode-categories.index');
    }

    protected function rules(): array
    {
        return [
            'mcodeCategory.published' => [
                'boolean',
            ],
            'mcodeCategory.name' => [
                'string',
                'nullable',
            ],
            'mcodeCategory.description' => [
                'string',
                'nullable',
            ],
            'mcodeCategory.slug' => [
                'string',
                'nullable',
            ],
            'mcodeCategory.order' => [
                'integer',
                'min:-2147483648',
                'max:2147483647',
                'nullable',
            ],
        ];
    }
}
