<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\McodeCommunication;
use Gate;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class McodeCommunicationController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('mcode_communication_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.mcode-communication.index');
    }

    public function create()
    {
        abort_if(Gate::denies('mcode_communication_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.mcode-communication.create');
    }

    public function edit(McodeCommunication $mcodeCommunication)
    {
        abort_if(Gate::denies('mcode_communication_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.mcode-communication.edit', compact('mcodeCommunication'));
    }

    public function show(McodeCommunication $mcodeCommunication)
    {
        abort_if(Gate::denies('mcode_communication_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.mcode-communication.show', compact('mcodeCommunication'));
    }
}
