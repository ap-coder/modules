<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\McodeCategory;
use Gate;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class McodeCategoryController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('mcode_category_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.mcode-category.index');
    }

    public function create()
    {
        abort_if(Gate::denies('mcode_category_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.mcode-category.create');
    }

    public function edit(McodeCategory $mcodeCategory)
    {
        abort_if(Gate::denies('mcode_category_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.mcode-category.edit', compact('mcodeCategory'));
    }

    public function show(McodeCategory $mcodeCategory)
    {
        abort_if(Gate::denies('mcode_category_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.mcode-category.show', compact('mcodeCategory'));
    }
}
