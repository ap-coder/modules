<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\McodeFeature;
use Gate;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class McodeFeatureController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('mcode_feature_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.mcode-feature.index');
    }

    public function create()
    {
        abort_if(Gate::denies('mcode_feature_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.mcode-feature.create');
    }

    public function edit(McodeFeature $mcodeFeature)
    {
        abort_if(Gate::denies('mcode_feature_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.mcode-feature.edit', compact('mcodeFeature'));
    }

    public function show(McodeFeature $mcodeFeature)
    {
        abort_if(Gate::denies('mcode_feature_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $mcodeFeature->load('catagories', 'communicationModes');

        return view('admin.mcode-feature.show', compact('mcodeFeature'));
    }
}
