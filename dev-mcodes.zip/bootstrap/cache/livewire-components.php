<?php return array (
  'm-code-category.create' => 'App\\Http\\Livewire\\MCodeCategory\\Create',
  'm-code-category.edit' => 'App\\Http\\Livewire\\MCodeCategory\\Edit',
  'm-code-category.index' => 'App\\Http\\Livewire\\MCodeCategory\\Index',
  'permission.create' => 'App\\Http\\Livewire\\Permission\\Create',
  'permission.edit' => 'App\\Http\\Livewire\\Permission\\Edit',
  'permission.index' => 'App\\Http\\Livewire\\Permission\\Index',
  'role.create' => 'App\\Http\\Livewire\\Role\\Create',
  'role.edit' => 'App\\Http\\Livewire\\Role\\Edit',
  'role.index' => 'App\\Http\\Livewire\\Role\\Index',
  'user.create' => 'App\\Http\\Livewire\\User\\Create',
  'user.edit' => 'App\\Http\\Livewire\\User\\Edit',
  'user.index' => 'App\\Http\\Livewire\\User\\Index',
);