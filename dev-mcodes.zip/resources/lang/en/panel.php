<?php

return [
    'site_title' => 'mcodes',
];
